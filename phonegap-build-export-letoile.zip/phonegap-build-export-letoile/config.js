define( function ( require ) {

	"use strict";

	return {
		app_slug : 'letoile',
		wp_ws_url : 'https://www.letoile.com.ar/wp-appkit-api/letoile',
		wp_url : 'https://www.letoile.com.ar',
		theme : 'q-ios',
		version : '1',
		app_type : 'phonegap-build',
		app_title : 'L\'etoile',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : 'O16>7.327NulV$S=Cyp9xx2)&+FNcNUHqkC[j>E_V1Ug5{r@cScPpmOA<3)U<,om',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
